const mongoose = require('mongoose');

const replySchema = new mongoose.Schema({
    word: {
        type: String,
        required: true,
        unique: true
    },
    reply: {
        type: String,
        required: true
    },
    role: {
        type: String
    }
});

const Reply = mongoose.model('Reply', replySchema);

module.exports = Reply;
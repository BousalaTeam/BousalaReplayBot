module.exports = {
    ownerID: '',
    token: '',
    id: '',
    imgUrl: ''
};
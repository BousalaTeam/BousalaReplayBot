const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const ReplyModel = require('../../models/Reply');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('add-reply')
        .setDescription('Add a reply')
        .addStringOption(option =>
            option.setName('word')
                .setDescription('The keyword')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reply')
                .setDescription('The reply')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('The role to restrict the reply to')),

    async execute(interaction, client) {
        const word = interaction.options.getString('word');
        const reply = interaction.options.getString('reply');
        const role = interaction.options.getRole('role');

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            await interaction.reply({content:'You do not have permissions to use this command.', ephemeral: true});
            return;
        }

           await ReplyModel.create({
               word: word,
               reply: reply,
               role: role ? role.id : null
           });

           await interaction.reply({content:`Reply added successfully! ${word}`, ephemeral: true});
        }
    }
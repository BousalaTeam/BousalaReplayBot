const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const ReplyModel = require('../../models/Reply');


module.exports = {
    data: new SlashCommandBuilder()
        .setName('delete-reply')
        .setDescription('Delete a reply')
        .addStringOption(option =>
            option.setName('word')
                .setDescription('The keyword of the reply to delete')
                .setRequired(true)),

    async execute(interaction, client) {
        const word = interaction.options.getString('word');

        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            await interaction.reply({content:'You do not have permissions to use this command.', ephemeral: true});
            return;
        }

        try {
            const deletedReply = await ReplyModel.findOneAndDelete({ word: word }).exec();
            
            if (deletedReply) {
                await interaction.reply({content:`Reply with keyword "${word}" deleted successfully!`, ephemeral: true});
            } else {
                await interaction.reply({content:`No reply found For "${word}".`, ephemeral: true});
            }
        } catch (error) {
            console.error('Error deleting reply:', error);
        }
    }
}
const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const ReplyModel = require('../../models/Reply');


module.exports = {
    data: new SlashCommandBuilder()
        .setName('reply-list')
        .setDescription('Show all stored replies'),

    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            await interaction.reply({content:'You do not have permissions to use this command.', ephemeral: true});
            return;
        }

        try {
            const replies = await ReplyModel.find();

            if (replies.length === 0) {
                await interaction.reply({content:'There are no stored replies.', ephemeral: true});
                return;
            }


            let replyList = 'Stored replies:\n';
            replies.forEach(reply => {
                replyList += `${reply.word}: ${reply.reply}\n`;
            });

            await interaction.reply({content: replyList, ephemeral: true});
        } catch (error) {
            console.error('Error fetching replies:', error);
            await interaction.reply({content:'An error occurred while fetching replies.', ephemeral: true});
        }
    }
}
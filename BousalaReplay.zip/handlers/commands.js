const { REST, Routes, Events, Client, ApplicationCommandType, Collection } = require('discord.js')
const config = require('../config')
const rest = new REST({ version: '10'}).setToken(config.token);
const { readdirSync } = require('node:fs')
const ascii = require('ascii-table')
const table = new ascii('Commands').setJustify();

module.exports = (client) => {
  const commands = [];
  client.commands = new Collection();
  readdirSync('./commands').forEach(folder => {
      const commandFiles = readdirSync(`./commands/${folder}`).filter(file => file.endsWith('.js'));

      for (const file of commandFiles) {
          const command = require(`../commands/${folder}/${file}`);
          if (command.name && command.description) {
              commands.push({
                  type: ApplicationCommandType.ChatInput,
                  name: command.name,
                  description: command.description,
                  options: command.options || []
              });
              client.commands.set(command.name, command);
              table.addRow(`/${command.name}`, '🟢 work');
          } else if (command.data?.name && command.data?.description) {
              commands.push(command.data.toJSON());
              client.commands.set(command.data.name, command);
              table.addRow(`/${command.data.name}`,'🟢 work');
          } else {
              table.addRow(file, '🔴 not work');
          }
      }
  });
  console.log(table.toString());
  client.once(Events.ClientReady, async c => {
      try {
          console.log(skyBlueGradient(`Started refreshing ${commands.length} application (/) commands.`));

          const data = await rest.put(
              Routes.applicationCommands(config.id),
              { body: commands },
          );
          console.log(skyBlueGradient(`Successfully reloaded ${data.length} application (/) commands.`));
      } catch (error) {
          console.error(error);
      }
  });
};
function skyBlueGradient(text) {
    const colors = [
        '\x1b[38;2;176;224;230m', 
        '\x1b[38;2;135;206;250m', 
        '\x1b[38;2;135;206;235m', 
        '\x1b[38;2;173;216;230m', 
        '\x1b[38;2;224;255;255m'  
    ];

    let gradientText = '';
    let colorIndex = 0;
    for (let i = 0; i < text.length; i++) {
        gradientText += colors[colorIndex] + text[i];
        colorIndex = (colorIndex + 1) % colors.length;
    }

    return gradientText + '\x1b[0m'; 
}
function redGradient(text) {
    let gradientText = '';
    for (let i = 0; i < text.length; i++) {
        const redValue = 255 - Math.floor((i / text.length) * 255);
        const color = `\x1b[38;2;${redValue};0;0m`; 
        gradientText += color + text[i];
    }
    return gradientText + '\x1b[0m'; 
}

function greenGradient(text) {
    let gradientText = '';
    for (let i = 0; i < text.length; i++) {
        const greenValue = 255 - Math.floor((i / text.length) * 255);
        const color = `\x1b[38;2;0;${greenValue};0m`; 
        gradientText += color + text[i];
    }
    return gradientText + '\x1b[0m';
}
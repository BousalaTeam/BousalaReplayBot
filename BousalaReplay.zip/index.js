
  /* require */
  const { Client, GatewayIntentBits, Events, Collection, ActionRowBuilder, ButtonBuilder, EmbedBuilder, TextInputStyle, ModalBuilder, TextInputBuilder, AttachmentBuilder } = require('discord.js');
  const config = require('./config')
  const fs = require('fs')
  const { readdirSync } = require('node:fs')
  const mongoose = require('./mongoose');
  const ReplyModel = require('./models/Reply');
  /* end require */
  
  /* ---------------------- */

  /* Client */
  const client = new Client({
      intents: Object.keys(GatewayIntentBits).map((a)=>{
        return GatewayIntentBits[a]
      }),
    });
  client.login(config.token)


  client.on('messageCreate', async message => {
    if (message.author.bot) return; 

    const word = message.content.toLowerCase();

    try {
        const replyData = await ReplyModel.findOne({ word: word }).exec();
        
        if (replyData) {
            const reply = replyData.reply;

            if (!replyData.role || message.member.roles.cache.has(replyData.role)) {
                message.channel.send(reply);
            } else {
              
            }
        }
    } catch (error) {
        console.error('Error retrieving reply from database:', error);
    }
});
  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (message.content === 'rules-panel') {
        if (message.author.id === config.ownerID) {
        const button1 = new ButtonBuilder()
        .setCustomId('designer_rules')
        .setLabel('Designer Rules')
        .setStyle(2);

    const button2 = new ButtonBuilder()
        .setCustomId('working_codes')
        .setLabel('Working Codes')
        .setStyle(2);

    const button3 = new ButtonBuilder()
        .setCustomId('tax_policy')
        .setLabel('Tax Policy')
        .setStyle(2);

    const image = new AttachmentBuilder(config.imgUrl);

    const row = new ActionRowBuilder()
        .addComponents(button1, button2, button3);


    const response = await message.channel.send({ components: [row], files: [image] });
} else {
    message.channel.send('Only the server owner can use this command.');
}
    }
});
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'designer_rules') {
        const designerEmbed = new EmbedBuilder()
        .setDescription(`1 - اتعامل باسلوب محترم مع العميل 
        2 - الصبر اثناء تلبيت الطلب
        3 - التعامل باسلوب رسمي
        4 - الالتزام ب #شروط الخادم
        5 - عدم التعامل مع العميل خارج التكت في الخاص / سيرفر اخر
        6 - يجب اتباع نظام الاكواد
        7 - الاتلزام باسعار الخطط
        8 - الالتزام بتسليم الطلب بعد تحويل المبلغ بشكل كامل مع ضرائب
        9 - عدم استلام طلبات في الخاص والتي مصدرها من خادمنا .
        10 - في حال كنت حامل لرتبة مصمم فهذا يفرض عليك التفاعل مع الطلبات لذا في حالة عدم تفاعل لمدة يومين متواصلين سوف يتم سحب الرتبة منك الا في حالة عدم توفر اي طلب من نفس تخصصك
        11 - اتباع نظام الضرائب | في حال عدم تاديت الضرائب المتفق عليها سوف يتم سحب رتبة منك بشكل مباشر
        12 - عدم استلام الطلبات التي لايمكنك تلبيتها`)
        .setColor('Blue');

        interaction.reply({ content: '**__هذة القوانين تنطبق علي الجميع و يمكن تغيرها في اي وقت وعدم قرائتك لها لا يعتبر عذرا__**', embeds: [designerEmbed], ephemeral: true })
    } else if (interaction.customId === 'working_codes') {
        const codesEmbed = new EmbedBuilder()
        .setDescription(`اكواد العمل
        
        # - اكواد نظام
        
        - C0
        > الكود الرئيسي ، يتم ارساله كاول كود داخل التكت من اجل 
        > تعريف وتنبيه العميل بان طلب قد تم استلامه .
        
        - C1
        > من اجل رائي العميل حول  الخدمة يستعمل هذا الكود 
        > فقط عند الانتهاء من الخدمه بشكل صحيح وكامل
        
        - C2
        > يستعمل للتنبيه العميل انه قد تم بدء تصميم الطلب
        
        # - اكواد الخطط
        
        __تستعمل هذه الاكواد لتسهيل عملية فهم طلب العميل وجمع معلومات حوله__
        
        ** - P1**
        > في حال كان طلب العميل بكج __Common__
        ** - P2**
        > في حال كان طلب العميل بكج __Middle__
        ** - P3**
        > في حال كان طلب العميل بكج __Beloved__`)
        .setColor('Blue');
        interaction.reply({ content:`تعمل هذه الاكواد علي تسهيل و اختصار المحادثات
        لتوفير خدمات بشكل سريع و بفعالية اكبر لذا يجب علي كل عضو ينتمي الي فريق المصممين ان يكون علي اطلاع علي هذه الاكواد`, embeds: [codesEmbed], ephemeral: true })
    } else if (interaction.customId === 'tax_policy') {
        const taxEmbed = new EmbedBuilder()
        .setDescription(`سياسة الضريبة
        
        # - ضوابط نظام الضرائب
        
        > هذا النظام ينطبق فقط علي حاملي رتبة فريق المصممين .
        > ينطبق عليك هاذا النظام فقط في حالة استلامك لطلب من الطلبات التي تنتلقاها بشكل جيد وكامل بعد تحويل العميل المبلغ الي حسابك .
        > بعد توصل بفاتورة التحويل من العميل والانتهاء من طلبه بشكل كامل يجب عليك مباشرة اجراء عملية حسابية من خلالها تقوم بتحويل 15% كنسبة الي حساب الخادم هذا الاجراء ضروري للاحتفاظ برتبتك
        > تحويل الضريبه في الغرفه المخصصة #تحويل ضريبة
        
        - يتم تحويل الضريبة ل @البنك
        
        # - نسبة الضريبة
        
        >تعتبر نسبة الضريبة قيمة ثابته تاخذ من كل عملية تحويل لاحد اعظاء فريق المصممين والتي تم الاتفاق عليها:
        
        - 15% : نسبة الخادم من كل عملية تحويل خاصة بخدمة التصاميم .`)
        .setColor('Blue');
        interaction.reply({ content:`يجب عليك الالتزام بسياسة الضريبة لتفادي الفصل هذه سياسة مفروضة فقط لاعظاء فريق المصممين .
        وجب تنبيه ان اي عملية قد تقوم بتوصل بالمبلغ الخص بها مسجلة عندنا ومراقبة لذا اي تلاعب قد يصدر منك سوف تحاسب عليه`, embeds: [taxEmbed], ephemeral: true })
    } 
});
  /* End Client */

  /* ---------------------- */
  
  /* consts */
  client.commands = new Collection();
  /* end consts */
  
  /* ---------------------- */
  
  
  
  
  
  /* Handler */
  readdirSync('./handlers').forEach(handler => {
      require(`./handlers/${handler}`)(client);
  });
  /* End Handler */
  
  /* ---------------------- */
  
  /* Process */
  process.on('SIGINT', () => {
    console.log(greenGradient('Shutting down...'));
    client.destroy();
    process.exit();
  });
  process.on('uncaughtException', (e) => {
  console.log(e)
  })
  process.on('rejectionHandled', (e) => {
    console.log(e)
  })
  /* End Process */

  //colors
  function skyBlueGradient(text) {
    const colors = [
        '\x1b[38;2;176;224;230m', 
        '\x1b[38;2;135;206;250m',
        '\x1b[38;2;135;206;235m', 
        '\x1b[38;2;173;216;230m', 
        '\x1b[38;2;224;255;255m'  
    ];

    let gradientText = '';
    let colorIndex = 0;
    for (let i = 0; i < text.length; i++) {
        gradientText += colors[colorIndex] + text[i];
        colorIndex = (colorIndex + 1) % colors.length;
    }

    return gradientText + '\x1b[0m'; 
}
function redGradient(text) {
    let gradientText = '';
    for (let i = 0; i < text.length; i++) {
        const redValue = 255 - Math.floor((i / text.length) * 255);
        const color = `\x1b[38;2;${redValue};0;0m`; 
        gradientText += color + text[i];
    }
    return gradientText + '\x1b[0m'; 
}

function greenGradient(text) {
    let gradientText = '';
    for (let i = 0; i < text.length; i++) {
        const greenValue = 255 - Math.floor((i / text.length) * 255);
        const color = `\x1b[38;2;0;${greenValue};0m`;
        gradientText += color + text[i];
    }
    return gradientText + '\x1b[0m'; 
}
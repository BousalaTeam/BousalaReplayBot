const { Events } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
    const text = `          ┌─────────────────────────┐
          │THE BOT READY FOR SERVICE│
          └─────────────────────────┘`;
    function skyBlueGradient(text) {
      const colors = [
          '\x1b[38;2;176;224;230m', 
          '\x1b[38;2;135;206;250m', 
          '\x1b[38;2;135;206;235m', 
          '\x1b[38;2;173;216;230m', 
          '\x1b[38;2;224;255;255m'  
      ];
  
      let gradientText = '';
      let colorIndex = 0;
      for (let i = 0; i < text.length; i++) {
          gradientText += colors[colorIndex] + text[i];
          colorIndex = (colorIndex + 1) % colors.length;
      }
  
      return gradientText + '\x1b[0m';
  }
  
  setTimeout(function() {
  console.log(skyBlueGradient(text));
  }, 3000)
  
    },
};